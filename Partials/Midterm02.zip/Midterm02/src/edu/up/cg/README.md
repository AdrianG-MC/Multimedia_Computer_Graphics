# 🎬 Video Creator — CLI

> AI-powered travel video creator. No GUI, no Maven, just Java.

---

## What it does

Place your travel photos/videos (with GPS data) in the `input/` folder, run the program, and it automatically produces a portrait-mode MP4 video that:

1. **Opens** with an AI-generated image capturing the spirit of your journey.
2. **Shows every media file** in chronological order, each narrated by an AI voice.
3. **Closes** with a map pinpointing your first and last GPS locations, plus an AI inspirational phrase.

The final video is saved to `output/Project_N/video.mp4` and your input files are moved there too (emptying `input/`).

---

## Requirements

Install these tools and make sure they are in your `PATH`:

| Tool | Purpose | Download |
|------|---------|----------|
| **JDK 17+** | Compile and run Java | https://adoptium.net |
| **ExifTool** | Read GPS & date from media | https://exiftool.org |
| **FFmpeg** | Encode the video | https://ffmpeg.org |

No Maven. No Gradle. No external Java libraries.

### Verify

```bash
java -version        # must show 17 or higher
javac -version       # same
exiftool -ver        # prints a version number
ffmpeg -version      # prints build info
```

---

## API Keys

| Key | Service | Where to get it |
|-----|---------|----------------|
| `GEMINI_API_KEY` | Google Gemini (text + image AI) | https://aistudio.google.com |
| `GEOAPIFY_API_KEY` | Geoapify (static map) | https://www.geoapify.com |

Both have free tiers that are sufficient for this project.

### Set environment variables

**macOS / Linux:**
```bash
export GEMINI_API_KEY="your_gemini_key"
export GEOAPIFY_API_KEY="your_geoapify_key"
```

Add to `~/.zshrc` or `~/.bashrc` to make permanent, then `source ~/.zshrc`.

**Windows CMD:**
```cmd
set GEMINI_API_KEY=your_gemini_key
set GEOAPIFY_API_KEY=your_geoapify_key
```

**Windows PowerShell:**
```powershell
$env:GEMINI_API_KEY="your_gemini_key"
$env:GEOAPIFY_API_KEY="your_geoapify_key"
```

> **Optional:** Set `GOOGLE_TTS_KEY` for a separate Google Cloud TTS key. Otherwise the program reuses `GEMINI_API_KEY` for narration.

---

## Build

### macOS / Linux

```bash
chmod +x build.sh
./build.sh
```

### Windows

```cmd
build.bat
```

This compiles all `.java` files and packages them into `video-creator.jar`.

---

## Usage

### Step 1 — Add media files

Drop your photos and/or videos into the `input/` folder.

```
VideoCreator/
└── input/
    ├── IMG_001.jpg
    ├── IMG_002.jpg
    └── VID_003.mp4
```

Files must have GPS data embedded (smartphones include this automatically when Location is enabled).

### Step 2 — Run

**macOS / Linux:**
```bash
# Compile + run in one step:
./build.sh run

# Or just run the already-built JAR:
java -jar video-creator.jar
```

**Windows:**
```cmd
build.bat run
```
or
```cmd
java -jar video-creator.jar
```

### Step 3 — Watch the pipeline run

The console shows each step with colored output:

```
══════════════════════════════════════════════════════
  ✈  VIDEO CREATOR — AI-Powered Travel Videos
══════════════════════════════════════════════════════

── Step 1: Loading media files from input/ ──
  Found: IMG_001.jpg
  Found: IMG_002.jpg
  Found: VID_003.mp4
  3 file(s) found.

── Step 2: Extracting EXIF metadata (GPS + date) ──
  [PHOTO] IMG_001.jpg | 19.4326,-99.1332 | 2024-03-10T14:23:00
  ...

── Step 3: Sorting media chronologically ──
  Sorted oldest → newest.

── Step 4: Generating AI content via Gemini ──
  → Generating opening AI image...
  ✔ Opening image ready.
  → Generating narration for each media item...
  ✔ Narrations generated.
  → Generating inspirational phrase...
  ✔ Phrase: "Every road leads somewhere beautiful..."

── Step 5: Generating narration audio (TTS) ──
  ✔ All audio files generated and normalized.

── Step 6: Generating map image (Geoapify) ──
  ✔ Map image ready.

── Step 7: Rendering final video with FFmpeg ──
  Project folder: output/Project_1
  Building opening clip...
  Building media clip 1/3...
  ...
  ✔ Video rendered: video.mp4

── Step 8: Moving input files to project folder ──
  ✔ Input folder emptied.

══════════════════════════════════════════════════════
  ✔  VIDEO CREATED SUCCESSFULLY!
  📁 /your/path/output/Project_1/video.mp4
══════════════════════════════════════════════════════
```

### Step 4 — Find your output

```
output/
└── Project_1/
    ├── video.mp4       ← your final video
    ├── IMG_001.jpg     ← original input files (moved here)
    ├── IMG_002.jpg
    └── VID_003.mp4
```

Every time you run the program, a new `Project_N` folder is created automatically.

---

## Supported media formats

| Type | Extensions |
|------|-----------|
| Photos | JPG, JPEG, PNG, HEIC, TIFF, WEBP |
| Videos | MP4, MOV, AVI, MKV, M4V, WMV |

All files **must** have GPS coordinates in their EXIF/metadata.  
Smartphone photos include GPS automatically when Location Services is enabled in the camera app.

---

## Output video specs

| Property | Value |
|----------|-------|
| Resolution | 1080 × 1920 px (portrait, 9:16) |
| Frame rate | 30 fps |
| Video codec | H.264 (libx264) |
| Audio codec | AAC, 192 kbps |
| Integrated loudness | −14 LUFS (YouTube standard) |
| True peak | −1.5 dBTP |
| LRA | 7 LU |

---

## Troubleshooting

| Problem | Solution |
|---------|---------|
| `javac not found` | Install JDK 17+ and add `JAVA_HOME/bin` to PATH |
| `exiftool not found` | Install ExifTool: https://exiftool.org |
| `ffmpeg not found` | Install FFmpeg: https://ffmpeg.org |
| `GEMINI_API_KEY is not set` | `export GEMINI_API_KEY=your_key` before running |
| `No media files could be processed` | Ensure files have GPS data; re-take photos with Location enabled |
| Compilation error | Ensure you are using Java 17+ (`javac -version`) |
| Map not generated | Check GEOAPIFY_API_KEY and internet connection |

---

## Project structure

```
VideoCreator/
├── src/com/videocreator/
│   ├── Main.java                        ← entry point / orchestrator
│   ├── loader/
│   │   ├── MediaLoader.java             ← discovers files in input/
│   │   └── LoaderException.java
│   ├── metadata/
│   │   ├── MediaItem.java               ← data model
│   │   ├── MetadataExtractor.java       ← ExifTool wrapper
│   │   └── MetadataException.java
│   ├── sorter/
│   │   └── MediaSorter.java             ← chronological sort
│   ├── ai/
│   │   ├── AIService.java               ← Gemini text + Imagen
│   │   └── AIException.java
│   ├── map/
│   │   ├── MapService.java              ← Geoapify + Java2D overlay
│   │   └── MapException.java
│   ├── audio/
│   │   ├── AudioGenerator.java          ← Google TTS + loudnorm
│   │   └── AudioException.java
│   ├── composer/
│   │   ├── VideoComposer.java           ← FFmpeg wrapper
│   │   └── ComposerException.java
│   └── util/
│       ├── ConsoleLogger.java           ← colored CLI output
│       ├── EnvConfig.java               ← environment variable helper
│       ├── TempFolder.java              ← temp directory lifecycle
│       ├── ProjectFolder.java           ← output/Project_N creation
│       └── ProcessRunner.java           ← subprocess execution
├── input/                               ← put your media here
├── output/                              ← videos saved here
│   └── Project_1/
│       ├── video.mp4
│       └── (input files moved here)
├── out/                                 ← compiled .class files
├── video-creator.jar                    ← runnable JAR
├── build.sh                             ← macOS/Linux build script
├── build.bat                            ← Windows build script
├── README.md
└── docs/
    └── TECHNICAL.md
```

---

## Clean up

```bash
./build.sh clean    # macOS/Linux
build.bat clean     # Windows
```

Removes `out/` and `video-creator.jar` (does not touch `input/` or `output/`).
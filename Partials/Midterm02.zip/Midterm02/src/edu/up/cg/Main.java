package edu.up.cg;


import edu.up.cg.services.AIService;
import edu.up.cg.services.MapService;
import edu.up.cg.tools.*;
import edu.up.cg.utils.ConsoleLogger;
import edu.up.cg.utils.EnvConfig;
import edu.up.cg.utils.ProjectFolder;
import edu.up.cg.utils.TempFolder;

import java.io.File;
import java.util.List;

/**
 * Main entry point for Video Creator (CLI version).
 *
 * <p>Orchestrates the full pipeline:
 * <ol>
 *   <li>Load media files from input/</li>
 *   <li>Extract EXIF metadata (GPS + date)</li>
 *   <li>Sort media chronologically</li>
 *   <li>Generate AI opening image</li>
 *   <li>Generate narration audio per item</li>
 *   <li>Generate closing map image with inspirational phrase</li>
 *   <li>Render final portrait video with FFmpeg</li>
 *   <li>Save output to output/Project_N/ and move input files there</li>
 * </ol>
 */
public class Main {

    /** Relative path to the media input folder. */
    public static final String INPUT_DIR  = "input";

    /** Relative path to the output root folder. */
    public static final String OUTPUT_DIR = "output";

    public static void main(String[] args) {
        ConsoleLogger.banner();

        // ── 0. Validate environment variables ──
        try {
            EnvConfig.requireEnv("GEMINI_API_KEY");
            EnvConfig.requireEnv("GEOAPIFY_API_KEY");
        } catch (IllegalStateException e) {
            ConsoleLogger.error(e.getMessage());
            System.exit(1);
        }

        File inputDir  = new File(INPUT_DIR);
        File outputDir = new File(OUTPUT_DIR);
        TempFolder tempFolder = null;

        try {
            // ── 1. Load media files ──
            ConsoleLogger.step(1, "Loading media files from input/");
            MediaLoader loader = new MediaLoader(inputDir);
            List<File> files = loader.load();
            ConsoleLogger.info(files.size() + " file(s) found.");

            // ── 2. Extract metadata ──
            ConsoleLogger.step(2, "Extracting EXIF metadata (GPS + date)");
            MetadataExtractor extractor = new MetadataExtractor();
            List<MediaItem> items = extractor.extractAll(files);
            ConsoleLogger.info(items.size() + " item(s) with valid metadata.");

            // ── 3. Sort by date ──
            ConsoleLogger.step(3, "Sorting media chronologically");
            MediaSorter sorter = new MediaSorter();
            List<MediaItem> sorted = sorter.sort(items);
            ConsoleLogger.info("Sorted oldest → newest.");

            // ── 4. Create temp working folder ──
            tempFolder = new TempFolder("vc_work_");
            ConsoleLogger.info("Temp folder: " + tempFolder.getPath());

            // ── 5. AI: opening image + narrations + phrase ──
            ConsoleLogger.step(4, "Generating AI content via Gemini");
            AIService ai = new AIService();

            ConsoleLogger.progress("Generating opening AI image...");
            File openingImage = ai.generateOpeningImage(sorted, tempFolder);
            ConsoleLogger.ok("Opening image ready.");

            ConsoleLogger.progress("Generating narration for each media item...");
            List<String> narrations = ai.generateNarrations(sorted);
            ConsoleLogger.ok("Narrations generated.");

            ConsoleLogger.progress("Generating inspirational phrase...");
            MediaItem first = sorted.get(0);
            MediaItem last  = sorted.get(sorted.size() - 1);
            String phrase = ai.generateInspirationalPhrase(first, last);
            ConsoleLogger.ok("Phrase: \"" + phrase + "\"");

            // ── 6. Audio: TTS narration per item + opening/closing ──
            ConsoleLogger.step(5, "Generating narration audio (TTS)");
            AudioGenerator audio = new AudioGenerator();

            File openingAudio = audio.synthesize(
                    "Welcome to your journey. Let's explore every moment.", tempFolder, "audio_opening");
            List<File> narrationAudios = audio.synthesizeAll(narrations, tempFolder);
            File closingAudio = audio.synthesize(
                    "Thank you for watching. Until the next adventure.", tempFolder, "audio_closing");
            ConsoleLogger.ok("All audio files generated and normalized.");

            // ── 7. Map image ──
            ConsoleLogger.step(6, "Generating map image (Geoapify)");
            MapService map = new MapService();
            File mapImage = map.generateMap(first, last, tempFolder);
            map.overlayPhrase(mapImage, phrase);
            ConsoleLogger.ok("Map image ready.");

            // ── 8. Render video ──
            ConsoleLogger.step(7, "Rendering final video with FFmpeg");
            ProjectFolder project = new ProjectFolder(outputDir);
            File projectDir = project.create();
            ConsoleLogger.info("Project folder: " + projectDir.getAbsolutePath());

            File outputVideo = new File(projectDir, "video.mp4");
            VideoComposer composer = new VideoComposer(tempFolder);
            composer.compose(openingImage, openingAudio,
                    sorted, narrationAudios,
                    mapImage, closingAudio,
                    outputVideo);
            ConsoleLogger.ok("Video rendered: " + outputVideo.getName());

            // ── 9. Move input files to project folder ──
            ConsoleLogger.step(8, "Moving input files to project folder");
            loader.moveFilesTo(projectDir);
            ConsoleLogger.ok("Input folder emptied. Files moved to " + projectDir.getName());

            // ── Done ──
            ConsoleLogger.done(outputVideo.getAbsolutePath());

        } catch (Exception e) {
            ConsoleLogger.error("Pipeline failed: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } finally {
            // Always clean up temp folder
            if (tempFolder != null) {
                tempFolder.delete();
                ConsoleLogger.info("Temp folder cleaned up.");
            }
        }
    }
}


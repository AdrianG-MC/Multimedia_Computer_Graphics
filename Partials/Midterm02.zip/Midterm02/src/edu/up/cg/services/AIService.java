package edu.up.cg.services;

import edu.up.cg.tools.MediaItem;
import edu.up.cg.utils.EnvConfig;
import edu.up.cg.utils.TempFolder;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.logging.Logger;

/**
 * AIService wraps the Google Gemini REST API for three tasks:
 *
 * <ol>
 *   <li>Generating a single opening image that captures the essence of the journey
 *       (via Imagen 3, falling back to a programmatic placeholder).</li>
 *   <li>Generating a short narration text for each media item (via Gemini 1.5 Flash).</li>
 *   <li>Generating an inspirational closing phrase for the map image.</li>
 * </ol>
 *
 * <p>Requires the {@code GEMINI_API_KEY} environment variable.
 */
public class AIService {

    private static final Logger LOG = Logger.getLogger(AIService.class.getName());

    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta/models/";
    private static final String TEXT_MODEL  = "gemini-1.5-flash:generateContent";
    private static final String IMAGE_MODEL = "imagen-3.0-generate-001:predict";

    /** Portrait frame dimensions used for the placeholder fallback. */
    private static final int FRAME_W = 1080;
    private static final int FRAME_H = 1920;

    private final String apiKey;
    private final HttpClient http;

    /**
     * Constructs an AIService reading the API key from the environment.
     *
     * @throws IllegalStateException if {@code GEMINI_API_KEY} is not set
     */
    public AIService() {
        this.apiKey = EnvConfig.requireEnv("GEMINI_API_KEY");
        this.http   = HttpClient.newHttpClient();
    }

    // ─────────────────── PUBLIC API ───────────────────

    /**
     * Generates the opening AI image that represents the spirit of the whole journey.
     *
     * <p>Steps:
     * <ol>
     *   <li>Ask Gemini Flash for a vivid Imagen prompt based on the media list.</li>
     *   <li>Send that prompt to Imagen 3 and decode the returned PNG.</li>
     *   <li>Fall back to a gradient placeholder if Imagen is unavailable.</li>
     * </ol>
     *
     * @param items     all media items (used to build the prompt)
     * @param tempFolder the temporary working directory
     * @return the generated PNG file
     * @throws Exception if both Imagen and the fallback fail
     */
    public File generateOpeningImage(List<MediaItem> items, TempFolder tempFolder)
            throws Exception {
        File out = new File(tempFolder.getPath(), "opening_image.png");

        // Step 1: build an image generation prompt
        String imagePrompt = generateEssencePrompt(items);

        // Step 2: call Imagen
        try {
            callImagen(imagePrompt, out);
            if (out.exists() && out.length() > 0) return out;
        } catch (Exception e) {
            LOG.warning("Imagen unavailable, using placeholder: " + e.getMessage());
        }

        // Step 3: fallback to a programmatic portrait gradient
        createGradientPlaceholder("✈ Your Journey", out);
        return out;
    }

    /**
     * Generates a two-sentence narration for each media item.
     * Items that fail individually get a metadata-based fallback description.
     *
     * @param items sorted list of media items
     * @return list of narration strings (same size and order as items)
     * @throws Exception if the Gemini API cannot be reached at all
     */
    public List<String> generateNarrations(List<MediaItem> items) throws Exception {
        List<String> narrations = new ArrayList<>();

        for (MediaItem item : items) {
            try {
                String text = describeItem(item);
                item.setNarration(text);
                narrations.add(text);
            } catch (Exception e) {
                LOG.warning("Narration failed for " + item.getFile().getName()
                        + ", using fallback: " + e.getMessage());
                String fallback = buildFallback(item);
                item.setNarration(fallback);
                narrations.add(fallback);
            }
        }
        return narrations;
    }

    /**
     * Generates a short inspirational phrase for the closing map image.
     *
     * @param first the first (oldest) media item
     * @param last  the last (newest) media item
     * @return one or two-sentence inspirational phrase
     * @throws Exception if Gemini fails
     */
    public String generateInspirationalPhrase(MediaItem first, MediaItem last)
            throws Exception {
        String prompt = String.format(
                "Write a short, poetic, and inspirational travel phrase (1-2 sentences) "
                        + "for a journey that started near coordinates (%.4f, %.4f) "
                        + "and ended near (%.4f, %.4f). "
                        + "Make it feel universal and meaningful. Do not mention coordinates.",
                first.getLatitude(), first.getLongitude(),
                last.getLatitude(),  last.getLongitude());

        return callGemini(prompt).trim();
    }

    // ─────────────────── PRIVATE: TEXT GENERATION ───────────────────

    /**
     * Asks Gemini to describe a single media item in 2 engaging sentences.
     * For photos, the image is encoded as base64 and sent inline (Vision).
     */
    private String describeItem(MediaItem item) throws Exception {
        String basePrompt = String.format(
                "Describe this %s in exactly 2 natural, engaging sentences as if narrating "
                        + "a travel video for an audience. Location: %.4f, %.4f. "
                        + "Date: %s. Be vivid and conversational.",
                item.getType() == MediaItem.Type.PHOTO ? "photo" : "video",
                item.getLatitude(), item.getLongitude(),
                item.getCaptureDate() != null ? item.getCaptureDate().toLocalDate() : "unknown");

        if (item.getType() == MediaItem.Type.PHOTO) {
            return callGeminiWithImage(basePrompt, item.getFile()).trim();
        } else {
            return callGemini(basePrompt).trim();
        }
    }

    /**
     * Asks Gemini to produce a vivid Imagen prompt representing all items.
     */
    private String generateEssencePrompt(List<MediaItem> items) throws Exception {
        StringBuilder sb = new StringBuilder(
                "Create a single concise image generation prompt (max 200 chars) "
                        + "for an AI image generator, capturing the essence of a travel journey "
                        + "through these locations:\n");
        for (MediaItem it : items) {
            sb.append(String.format("  - %s at (%.4f, %.4f)\n",
                    it.getFile().getName(), it.getLatitude(), it.getLongitude()));
        }
        sb.append("The prompt must describe a portrait-oriented, cinematic, artistic scene. "
                + "Respond with ONLY the prompt text, nothing else.");
        return callGemini(sb.toString()).trim();
    }

    // ─────────────────── PRIVATE: HTTP CALLS ───────────────────

    /**
     * Sends a text-only prompt to Gemini Flash and returns the response text.
     *
     * @param prompt the user prompt
     * @return the model's text response
     * @throws Exception on HTTP or parsing failure
     */
    private String callGemini(String prompt) throws Exception {
        String url  = BASE + TEXT_MODEL + "?key=" + apiKey;
        String body = buildTextRequest(prompt, null, null);
        return postAndExtractText(url, body);
    }

    /**
     * Sends a text prompt + inline base64 image to Gemini Vision.
     *
     * @param prompt    the text instruction
     * @param imageFile the image file to encode and include
     * @return the model's text response
     * @throws Exception on HTTP or IO failure
     */
    private String callGeminiWithImage(String prompt, File imageFile) throws Exception {
        try {
            byte[] bytes = Files.readAllBytes(imageFile.toPath());
            String b64   = Base64.getEncoder().encodeToString(bytes);
            String mime  = guessMime(imageFile);
            String url   = BASE + TEXT_MODEL + "?key=" + apiKey;
            String body  = buildTextRequest(prompt, b64, mime);
            return postAndExtractText(url, body);
        } catch (IOException e) {
            // Fall back to text-only if image cannot be read
            return callGemini(prompt);
        }
    }

    /**
     * Sends a prompt to Imagen 3 and writes the resulting PNG to {@code out}.
     *
     * @param prompt image generation prompt
     * @param out    destination file
     * @throws Exception if Imagen returns an error or empty response
     */
    private void callImagen(String prompt, File out) throws Exception {
        String url  = BASE + IMAGE_MODEL + "?key=" + apiKey;
        String body = String.format("""
                {
                  "instances": [{"prompt": "%s"}],
                  "parameters": {"sampleCount": 1, "aspectRatio": "9:16"}
                }""", escapeJson(prompt));

        String response = post(url, body);
        String b64 = extractField(response, "bytesBase64Encoded");
        if (b64 == null || b64.isEmpty()) {
            throw new Exception("Imagen returned no image data.");
        }
        try {
            Files.write(out.toPath(), Base64.getDecoder().decode(b64));
        } catch (IOException e) {
            throw new Exception("Could not write Imagen output: " + e.getMessage(), e);
        }
    }

    /** Sends an HTTP POST with JSON body and returns the raw response body. */
    private String post(String url, String body) throws Exception {
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (res.statusCode() != 200) {
                throw new Exception("Gemini API HTTP " + res.statusCode() + ": " + res.body());
            }
            return res.body();
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            throw new Exception("HTTP request failed: " + e.getMessage(), e);
        }
    }

    /** Calls {@link #post} and extracts the first "text" field from the Gemini response. */
    private String postAndExtractText(String url, String body) throws Exception {
        String response = post(url, body);
        String text = extractField(response, "text");
        if (text == null || text.isEmpty()) {
            throw new Exception("Empty text response from Gemini.");
        }
        return text;
    }

    // ─────────────────── PRIVATE: JSON HELPERS ───────────────────

    /**
     * Builds a Gemini generateContent request body.
     * If {@code b64} is non-null, includes an inlineData image part.
     */
    private String buildTextRequest(String prompt, String b64, String mime) {
        String imagePart = (b64 != null)
                ? String.format("""
                          ,{"inlineData": {"mimeType": "%s", "data": "%s"}}
                          """, mime, b64)
                : "";

        return String.format("""
                {
                  "contents": [{"parts": [
                    {"text": "%s"}%s
                  ]}],
                  "generationConfig": {"temperature": 0.7, "maxOutputTokens": 400}
                }""", escapeJson(prompt), imagePart);
    }

    /**
     * Extracts the first occurrence of {@code "field": "value"} from a JSON string.
     * Simple hand-written parser — avoids any JSON library dependency.
     */
    private String extractField(String json, String field) {
        String key = "\"" + field + "\":";
        int idx = json.indexOf(key);
        if (idx < 0) return null;
        idx += key.length();
        // Skip whitespace and opening quote
        while (idx < json.length() && json.charAt(idx) != '"') idx++;
        if (idx >= json.length()) return null;
        idx++; // skip opening quote

        StringBuilder sb = new StringBuilder();
        while (idx < json.length() && json.charAt(idx) != '"') {
            char c = json.charAt(idx);
            if (c == '\\' && idx + 1 < json.length()) {
                char next = json.charAt(++idx);
                switch (next) {
                    case 'n'  -> sb.append('\n');
                    case 't'  -> sb.append('\t');
                    case '"'  -> sb.append('"');
                    case '\\' -> sb.append('\\');
                    default   -> { sb.append('\\'); sb.append(next); }
                }
            } else {
                sb.append(c);
            }
            idx++;
        }
        return sb.toString();
    }

    /** Escapes special characters for use inside a JSON string literal. */
    private String escapeJson(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    /** Guesses the MIME type of an image file by extension. */
    private String guessMime(File file) {
        String ext = file.getName().toLowerCase();
        if (ext.endsWith(".png"))  return "image/png";
        if (ext.endsWith(".webp")) return "image/webp";
        if (ext.endsWith(".gif"))  return "image/gif";
        return "image/jpeg";
    }

    // ─────────────────── PRIVATE: FALLBACKS ───────────────────

    /**
     * Returns a plain-text fallback description when Gemini is unavailable.
     */
    private String buildFallback(MediaItem item) {
        return String.format("A %s captured on %s near coordinates %.4f, %.4f.",
                item.getType() == MediaItem.Type.PHOTO ? "photo" : "video",
                item.getCaptureDate() != null
                        ? item.getCaptureDate().toLocalDate().toString() : "an unknown date",
                item.getLatitude(), item.getLongitude());
    }

    /**
     * Creates a 1080×1920 gradient PNG using Java2D as an Imagen fallback.
     *
     * @param label text to display at the center of the image
     * @param out   the PNG file to write
     * @throws Exception if ImageIO fails
     */
    private void createGradientPlaceholder(String label, File out) throws Exception {
        BufferedImage img = new BufferedImage(FRAME_W, FRAME_H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Navy → deep purple gradient
        GradientPaint gp = new GradientPaint(0, 0, new Color(10, 10, 70),
                0, FRAME_H, new Color(70, 0, 100));
        g.setPaint(gp);
        g.fillRect(0, 0, FRAME_W, FRAME_H);

        // Centered white label
        g.setColor(Color.WHITE);
        g.setFont(new Font("SansSerif", Font.BOLD, 90));
        FontMetrics fm = g.getFontMetrics();
        int x = (FRAME_W - fm.stringWidth(label)) / 2;
        int y = FRAME_H / 2;
        g.drawString(label, x, y);
        g.dispose();

        try {
            ImageIO.write(img, "PNG", out);
        } catch (IOException e) {
            throw new Exception("Could not write placeholder image: " + e.getMessage(), e);
        }
    }
}


package edu.up.cg.services;


import edu.up.cg.tools.MediaItem;
import edu.up.cg.utils.EnvConfig;
import edu.up.cg.utils.TempFolder;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;

/**
 * MapService fetches a static map image from the Geoapify Static Maps API
 * with two distinct markers (green = start, red = end), then uses Java2D
 * to overlay the AI-generated inspirational phrase onto the image.
 *
 * <p>Requires the {@code GEOAPIFY_API_KEY} environment variable.
 */
public class MapService {

    private static final String API_URL = "https://maps.geoapify.com/v1/staticmap";

    /** Portrait frame dimensions — must match the video frame. */
    private static final int MAP_W = 1080;
    private static final int MAP_H = 1920;

    /** Height of the semi-transparent text banner at the bottom. */
    private static final int BANNER_H = 360;

    private final String apiKey;
    private final HttpClient http;

    /**
     * Constructs a MapService reading the Geoapify key from the environment.
     *
     * @throws IllegalStateException if {@code GEOAPIFY_API_KEY} is not set
     */
    public MapService() {
        this.apiKey = EnvConfig.requireEnv("GEOAPIFY_API_KEY");
        this.http   = HttpClient.newHttpClient();
    }

    /**
     * Downloads a static map image from Geoapify with two distinct pin markers.
     *
     * <ul>
     *   <li>Green marker — first (oldest) location</li>
     *   <li>Red   marker — last  (newest) location</li>
     * </ul>
     *
     * @param first      the oldest media item
     * @param last       the newest media item
     * @param tempFolder the temporary working directory
     * @return the downloaded PNG map file
     * @throws Exception if the API call or file write fails
     */
    public File generateMap(MediaItem first, MediaItem last, TempFolder tempFolder)
            throws Exception {
        File out = new File(tempFolder.getPath(), "map_image.png");

        String url = buildUrl(
                first.getLatitude(), first.getLongitude(),
                last.getLatitude(),  last.getLongitude());

        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();
            HttpResponse<byte[]> res = http.send(req, HttpResponse.BodyHandlers.ofByteArray());

            if (res.statusCode() != 200) {
                throw new Exception("Geoapify returned HTTP " + res.statusCode());
            }
            Files.write(out.toPath(), res.body());
        } catch (IOException | InterruptedException e) {
            if (e instanceof InterruptedException) Thread.currentThread().interrupt();
            throw new Exception("Map download failed: " + e.getMessage(), e);
        }
        return out;
    }

    /**
     * Overlays a semi-transparent banner and the inspirational phrase
     * onto the map PNG file <em>in place</em>.
     *
     * <p>Also draws a legend showing "● Start" (green) and "● End" (red).
     *
     * @param mapFile the PNG file to modify
     * @param phrase  the text to render
     * @throws Exception if the image cannot be read or written
     */
    public void overlayPhrase(File mapFile, String phrase) throws Exception {
        try {
            BufferedImage img = ImageIO.read(mapFile);
            if (img == null) throw new Exception("Could not read map image.");

            Graphics2D g = img.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                    RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int w = img.getWidth();
            int h = img.getHeight();

            // ── Semi-transparent dark banner ──
            g.setColor(new Color(0, 0, 0, 190));
            g.fillRect(0, h - BANNER_H, w, BANNER_H);

            // ── Inspirational phrase (word-wrapped) ──
            g.setColor(Color.WHITE);
            g.setFont(new Font("SansSerif", Font.ITALIC, 54));
            drawWrapped(g, phrase, 60, h - BANNER_H + 80, w - 120, 64);

            // ── Start / End legend ──
            g.setFont(new Font("SansSerif", Font.BOLD, 40));
            g.setColor(new Color(30, 210, 100));
            g.drawString("● Start", 60, h - 60);
            g.setColor(new Color(255, 70, 70));
            g.drawString("● End", 340, h - 60);

            g.dispose();
            ImageIO.write(img, "PNG", mapFile);

        } catch (IOException e) {
            throw new Exception("Failed to overlay phrase: " + e.getMessage(), e);
        }
    }

    // ─────────────────── PRIVATE HELPERS ───────────────────

    /**
     * Builds the Geoapify Static Maps URL.
     *
     * <p>Marker format: {@code lonlat:<lon>,<lat>;color:<hex>;size:large;type:material}
     */
    private String buildUrl(double lat1, double lon1, double lat2, double lon2) {
        double centerLat = (lat1 + lat2) / 2.0;
        double centerLon = (lon1 + lon2) / 2.0;
        int    zoom      = estimateZoom(lat1, lon1, lat2, lon2);

        // %23 = '#' URL-encoded (Geoapify requires this for the hex colour)
        String startMarker = String.format(
                "lonlat:%f,%f;color:%%2300cc55;size:large;type:material",
                lon1, lat1);
        String endMarker = String.format(
                "lonlat:%f,%f;color:%%23ff3333;size:large;type:material",
                lon2, lat2);

        return String.format(
                "%s?style=osm-bright&width=%d&height=%d"
                        + "&center=lonlat:%f,%f&zoom=%d"
                        + "&marker=%s&marker=%s"
                        + "&apiKey=%s",
                API_URL, MAP_W, MAP_H,
                centerLon, centerLat, zoom,
                startMarker, endMarker,
                apiKey);
    }

    /**
     * Estimates the Geoapify zoom level so that both markers are comfortably visible.
     *
     * @return zoom integer between 1 and 15
     */
    private int estimateZoom(double lat1, double lon1, double lat2, double lon2) {
        double delta = Math.max(Math.abs(lat1 - lat2), Math.abs(lon1 - lon2));
        if (delta < 0.01) return 15;
        if (delta < 0.1)  return 12;
        if (delta < 0.5)  return 10;
        if (delta < 2.0)  return 8;
        if (delta < 10.0) return 6;
        if (delta < 30.0) return 4;
        return 2;
    }

    /**
     * Draws word-wrapped text inside a bounding box.
     *
     * @param g          the graphics context
     * @param text       the text to render
     * @param x          left edge of the text area
     * @param y          top-left y position of the first line
     * @param maxWidth   maximum line width in pixels
     * @param lineHeight vertical spacing between lines in pixels
     */
    private void drawWrapped(Graphics2D g, String text, int x, int y,
                             int maxWidth, int lineHeight) {
        FontMetrics fm = g.getFontMetrics();
        String[] words = text.split("\\s+");
        StringBuilder line = new StringBuilder();
        int curY = y;

        for (String word : words) {
            String candidate = line.isEmpty() ? word : line + " " + word;
            if (fm.stringWidth(candidate) > maxWidth && !line.isEmpty()) {
                g.drawString(line.toString(), x, curY);
                line = new StringBuilder(word);
                curY += lineHeight;
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (!line.isEmpty()) {
            g.drawString(line.toString(), x, curY);
        }
    }
}
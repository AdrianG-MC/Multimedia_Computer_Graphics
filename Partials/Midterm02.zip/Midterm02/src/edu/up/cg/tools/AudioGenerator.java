package edu.up.cg.tools;

import edu.up.cg.utils.EnvConfig;
import edu.up.cg.utils.ProcessRunner;
import edu.up.cg.utils.TempFolder;

import java.io.*;
import java.net.URI;
import java.net.http.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.logging.Logger;

/**
 * AudioGenerator converts text to speech using the Google Cloud TTS REST API,
 * then normalizes the resulting MP3 to meet YouTube audio standards using FFmpeg.
 *
 * <p>YouTube audio requirements met:
 * <ul>
 *   <li>Integrated loudness: −14 LUFS (target; within −16 to −14 range)</li>
 *   <li>True peak: −1.5 dBTP (within −2 to −1 range)</li>
 *   <li>LRA: 7 LU (within 5–10 LU range)</li>
 * </ul>
 *
 * <p>Falls back to silent audio when TTS is unavailable so the video
 * pipeline never blocks.
 *
 * <p>Requires {@code GEMINI_API_KEY} (reused as TTS key) or {@code GOOGLE_TTS_KEY}.
 */
public class AudioGenerator {

    private static final Logger LOG = Logger.getLogger(AudioGenerator.class.getName());

    /** Google Cloud TTS endpoint. */
    private static final String TTS_URL =
            "https://texttospeech.googleapis.com/v1/text:synthesize?key=";

    /** FFmpeg loudnorm filter targeting YouTube standards. */
    private static final String LOUDNORM = "loudnorm=I=-14:TP=-1.5:LRA=7";

    private final String apiKey;
    private final HttpClient http;

    /**
     * Constructs an AudioGenerator.
     * Prefers {@code GOOGLE_TTS_KEY}, falls back to {@code GEMINI_API_KEY}.
     */
    public AudioGenerator() {
        String key = System.getenv("GOOGLE_TTS_KEY");
        if (key == null || key.isBlank()) {
            key = EnvConfig.requireEnv("GEMINI_API_KEY");
        }
        this.apiKey = key;
        this.http   = HttpClient.newHttpClient();
    }

    /**
     * Synthesizes a single text string to an MP3 file in the temp folder.
     *
     * @param text       the narration text
     * @param tempFolder working directory for the output file
     * @param baseName   filename without extension (e.g. {@code "audio_01"})
     * @return the normalized MP3 file
     * @throws Exception if both TTS and the silence fallback fail
     */
    public File synthesize(String text, TempFolder tempFolder, String baseName)
            throws Exception {

        File mp3 = new File(tempFolder.getPath(), baseName + ".mp3");

        if (text == null || text.isBlank()) {
            generateSilence(mp3, 3.0);
            return mp3;
        }

        try {
            byte[] audioBytes = callTts(text);
            Files.write(mp3.toPath(), audioBytes);
            normalizeLoudness(mp3, tempFolder);
            return mp3;

        } catch (IOException e) {
            LOG.warning("TTS I/O error, using silence: " + e.getMessage());
        } catch (Exception e) {
            LOG.warning("TTS failed, using silence: " + e.getMessage());
        }

        // Fallback: silent audio
        generateSilence(mp3, estimateDuration(text));
        return mp3;
    }

    /**
     * Synthesizes narration audio for a list of texts, one MP3 per item.
     *
     * @param texts      narration strings (one per media item)
     * @param tempFolder working directory
     * @return list of MP3 files in the same order as {@code texts}
     * @throws Exception if a critical failure occurs
     */
    public List<File> synthesizeAll(List<String> texts, TempFolder tempFolder)
            throws Exception {

        List<File> files = new ArrayList<>();
        for (int i = 0; i < texts.size(); i++) {
            String baseName = String.format("audio_%02d", i + 1);
            File f = synthesize(texts.get(i), tempFolder, baseName);
            files.add(f);
            LOG.info("Audio " + (i + 1) + "/" + texts.size() + " → " + f.getName());
        }
        return files;
    }

    /**
     * Generates a silent MP3 of the given duration using FFmpeg's {@code anullsrc} source.
     *
     * @param output   the MP3 file to create
     * @param seconds  duration of silence in seconds
     * @throws Exception if FFmpeg fails
     */
    public void generateSilence(File output, double seconds) throws Exception {
        String[] cmd = {
                "ffmpeg", "-y",
                "-f", "lavfi",
                "-i", "anullsrc=r=44100:cl=stereo",
                "-t", String.valueOf(seconds),
                "-q:a", "2",
                output.getAbsolutePath()
        };
        try {
            ProcessRunner.run(cmd, "generate silence");
        } catch (Exception e) {
            throw new Exception("Could not generate silence: " + e.getMessage(), e);
        }
    }

    // ─────────────────── PRIVATE HELPERS ───────────────────

    /**
     * Calls the Google Cloud TTS API and returns the decoded MP3 bytes.
     *
     * @param text the text to synthesize
     * @return raw MP3 audio bytes
     * @throws Exception if the API returns an error
     * @throws IOException    if the HTTP request fails
     */
    private byte[] callTts(String text) throws Exception, IOException {
        String body = buildTtsRequest(text);
        try {
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(TTS_URL + apiKey))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();

            HttpResponse<String> res = http.send(req, HttpResponse.BodyHandlers.ofString());

            if (res.statusCode() != 200) {
                throw new Exception("TTS HTTP " + res.statusCode() + ": " + res.body());
            }

            String b64 = extractAudioContent(res.body());
            if (b64 == null || b64.isEmpty()) {
                throw new Exception("TTS returned empty audio.");
            }
            return Base64.getDecoder().decode(b64);

        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new Exception("TTS request interrupted.", e);
        }
    }

    /**
     * Applies FFmpeg loudness normalization to an MP3 file in-place.
     * Target: −14 LUFS integrated, −1.5 dBTP true peak, 7 LU LRA.
     *
     * @param mp3        the file to normalize (replaced with normalized version)
     * @param tempFolder used for a temporary intermediate file
     */
    private void normalizeLoudness(File mp3, TempFolder tempFolder) {
        File tmp = new File(tempFolder.getPath(), "norm_" + mp3.getName());
        String[] cmd = {
                "ffmpeg", "-y",
                "-i", mp3.getAbsolutePath(),
                "-af", LOUDNORM,
                "-ar", "44100",
                "-ac", "2",
                tmp.getAbsolutePath()
        };
        try {
            ProcessRunner.run(cmd, "loudness normalization");
            Files.move(tmp.toPath(), mp3.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (Exception e) {
            LOG.warning("Loudness normalization failed (audio still usable): " + e.getMessage());
            tmp.delete();
        }
    }

    /**
     * Builds the Google Cloud TTS JSON request body.
     * Uses the en-US Neural2-D voice for natural-sounding narration.
     */
    private String buildTtsRequest(String text) {
        String escaped = text
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", " ");

        return String.format("""
                {
                  "input": {"text": "%s"},
                  "voice": {
                    "languageCode": "en-US",
                    "name": "en-US-Neural2-D",
                    "ssmlGender": "NEUTRAL"
                  },
                  "audioConfig": {
                    "audioEncoding": "MP3",
                    "speakingRate": 0.95,
                    "sampleRateHertz": 44100
                  }
                }""", escaped);
    }

    /**
     * Extracts the base64 {@code audioContent} field from a TTS API response.
     */
    private String extractAudioContent(String json) {
        String key = "\"audioContent\":";
        int idx = json.indexOf(key);
        if (idx < 0) return null;
        idx += key.length();
        while (idx < json.length() && json.charAt(idx) != '"') idx++;
        if (idx >= json.length()) return null;
        idx++; // skip opening quote
        int end = json.indexOf('"', idx);
        return end < 0 ? null : json.substring(idx, end);
    }

    /**
     * Estimates audio duration in seconds based on average speaking rate (~3 words/sec).
     *
     * @param text the narration text
     * @return estimated seconds (minimum 3)
     */
    private double estimateDuration(String text) {
        int words = text.trim().split("\\s+").length;
        return Math.max(3.0, words / 3.0);
    }
}
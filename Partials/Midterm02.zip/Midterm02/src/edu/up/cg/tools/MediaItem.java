package edu.up.cg.tools;


import edu.up.cg.tools.MetadataExtractor;

import java.io.File;
import java.time.LocalDateTime;

/**
 * Immutable-ish data model representing a single media file with its extracted metadata.
 *
 * <p>Fields are set after construction by {@link MetadataExtractor}.
 * The class implements {@link Comparable} so a plain {@code Collections.sort()}
 * produces chronological order without a separate Comparator.
 */

public class MediaItem implements Comparable<MediaItem> {

    // Type of media content
    public enum Type { PHOTO, VIDEO }

    // ── Core fields ──
    private final File file;
    private final Type   type;

    // ── Metadata (set by MetadataExtractor) ──
    private double latitude;
    private double longitude;
    private LocalDateTime captureDate;

    // ── AI content (set by AIService) ──
    private String narration;

    /**
     * Constructs a MediaItem from a file reference.
     * The type is derived from the file extension.
     *
     * @param file the media file on disk
     */
    public MediaItem(File file) {
        this.file = file;
        this.type = detectType(file.getName());
    }

    // ── Type detection ──

    private static Type detectType(String name) {
        String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase();

        if (ext.equals("mp4") || ext.equals("mov") || ext.equals("avi")) {
            return Type.VIDEO;
        }

        return Type.PHOTO;
    }

    // Getters

    /** Returns the underlying file. */
    public File getFile() { return file; }

    /** Returns whether this item is a photo or video. */
    public Type getType() { return type; }

    /** Returns the GPS latitude in decimal degrees. */
    public double getLatitude() { return latitude; }

    /** Returns the GPS longitude in decimal degrees. */
    public double getLongitude() { return longitude; }

    /** Returns the capture date extracted from EXIF metadata, or null if unavailable. */
    public LocalDateTime getCaptureDate() { return captureDate; }

    /** Returns the AI-generated narration text for this item. */
    public String getNarration() { return narration; }

    // ── Setters (used by MetadataExtractor and AIService) ──

    public void setLatitude(double latitude)       { this.latitude = latitude; }
    public void setLongitude(double longitude)     { this.longitude = longitude; }
    public void setCaptureDate(LocalDateTime date) { this.captureDate = date; }
    public void setNarration(String narration)     { this.narration = narration; }

    // ── Helpers ──

    /**
     * Returns {@code true} if the item has non-zero GPS coordinates.
     */
    public boolean hasGps() {
        return latitude != 0.0 || longitude != 0.0;
    }

    /**
     * Compares by capture date, oldest first.
     * Items with no date sort to the end.
     */
    @Override
    public int compareTo(MediaItem other) {
        if (this.captureDate == null && other.captureDate == null) return 0;
        if (this.captureDate == null) return 1;
        if (other.captureDate == null) return -1;
        return this.captureDate.compareTo(other.captureDate);
    }

    @Override
    public String toString() {
        return String.format("[%s] %s | %.4f,%.4f | %s",
                type, file.getName(), latitude, longitude, captureDate);
    }
}

package edu.up.cg.tools;



import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * MediaSorter orders a list of {@link MediaItem} objects chronologically
 * (oldest capture date first).
 *
 * <p>Items with no capture date are placed at the end.
 * The original list is not modified — a new sorted list is returned.
 */
public class MediaSorter {

    /**
     * Returns a new list of media items sorted from oldest to newest.
     *
     * <p>Relies on {@link MediaItem#compareTo(MediaItem)} which compares
     * {@code captureDate} fields via {@link java.time.LocalDateTime#compareTo}.
     *
     * @param items unsorted list of media items
     * @return new list sorted chronologically (oldest first)
     */
    public List<MediaItem> sort(List<MediaItem> items) {
        List<MediaItem> sorted = new ArrayList<>(items);
        Collections.sort(sorted);
        return sorted;
    }
}
package edu.up.cg.tools;

import edu.up.cg.tools.MediaItem;
import edu.up.cg.utils.ProcessRunner;
import edu.up.cg.utils.TempFolder;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * VideoComposer builds the final portrait-mode MP4 using FFmpeg.
 *
 * <p>Pipeline:
 * <ol>
 *   <li>Convert each (image/video + audio) pair into a short portrait MP4 clip.</li>
 *   <li>Write a concat list file.</li>
 *   <li>Concatenate all clips with a final loudness normalization pass.</li>
 * </ol>
 *
 * <p>Portrait frame: {@code 1080 × 1920} px (9:16).
 * All media is scaled to fill the frame while preserving its original aspect ratio.
 * Any remaining space is padded with black bars.
 */
public class VideoComposer {

    // ── Video frame ──
    public static final int FRAME_W = 1080;
    public static final int FRAME_H = 1920;
    public static final int FPS     = 30;

    // ── Clip durations (seconds) ──
    private static final double DUR_OPENING = 4.0;
    private static final double DUR_PHOTO   = 5.0;
    private static final double DUR_CLOSING = 8.0;

    /** FFmpeg scale+pad filter that fills 1080×1920 preserving aspect ratio. */
    private static final String SCALE_PAD = String.format(
            "scale=%d:%d:force_original_aspect_ratio=decrease,"
                    + "pad=%d:%d:(ow-iw)/2:(oh-ih)/2:black",
            FRAME_W, FRAME_H, FRAME_W, FRAME_H);

    /** Final loudness normalization targeting YouTube standard. */
    private static final String LOUDNORM = "loudnorm=I=-14:TP=-1.5:LRA=7";

    private final TempFolder temp;

    /**
     * Constructs a VideoComposer that writes intermediate clips to the given temp folder.
     *
     * @param temp the temporary working directory
     */
    public VideoComposer(TempFolder temp) {
        this.temp = temp;
    }

    /**
     * Assembles the complete video from all segments and writes it to {@code outputFile}.
     *
     * @param openingImage    AI-generated opening PNG
     * @param openingAudio    narration MP3 for the opening
     * @param items           sorted list of media items
     * @param narrationAudios narration MP3s (same order as items)
     * @param mapImage        closing map PNG
     * @param closingAudio    narration MP3 for the closing
     * @param outputFile      the final MP4 to create
     * @throws Exception if any FFmpeg step fails
     */
    public void compose(File openingImage, File openingAudio,
                        List<MediaItem> items, List<File> narrationAudios,
                        File mapImage, File closingAudio,
                        File outputFile) throws Exception {

        List<File> clips = new ArrayList<>();

        try {
            // ── Opening clip ──
            System.out.println("  Building opening clip...");
            clips.add(buildImageClip(openingImage, openingAudio, DUR_OPENING, "clip_00_opening"));

            // ── One clip per media item ──
            for (int i = 0; i < items.size(); i++) {
                System.out.println(String.format("  Building media clip %d/%d...",
                        i + 1, items.size()));
                MediaItem item  = items.get(i);
                File      audio = narrationAudios.get(i);
                String    name  = String.format("clip_%02d_media", i + 1);

                File clip = (item.getType() == MediaItem.Type.PHOTO)
                        ? buildImageClip(item.getFile(), audio, DUR_PHOTO, name)
                        : buildVideoClip(item.getFile(), audio, name);

                clips.add(clip);
            }

            // ── Closing map clip ──
            System.out.println("  Building closing map clip...");
            clips.add(buildImageClip(mapImage, closingAudio, DUR_CLOSING, "clip_99_map"));

            // ── Concatenate ──
            System.out.println("  Concatenating " + clips.size() + " clips...");
            concatenate(clips, outputFile);

        } finally {
            // Delete intermediate clips regardless of success/failure
            clips.forEach(f -> { if (f != null) f.delete(); });
        }
    }

    // ─────────────────── CLIP BUILDERS ───────────────────

    /**
     * Converts a still image + audio file into a portrait MP4 clip.
     *
     * <p>The image is looped (via {@code -loop 1}) for the specified duration.
     * Audio is trimmed or padded with silence to match the video length.
     *
     * @param image    the source image file
     * @param audio    the narration MP3
     * @param duration clip length in seconds
     * @param name     base filename for the output clip (no extension)
     * @return the generated MP4 file
     * @throws Exception if FFmpeg fails
     */
    private File buildImageClip(File image, File audio, double duration, String name)
            throws Exception {

        File out = new File(temp.getPath(), name + ".mp4");
        String[] cmd = {
                "ffmpeg", "-y",
                "-loop", "1",
                "-i", image.getAbsolutePath(),
                "-i", audio.getAbsolutePath(),
                "-vf", SCALE_PAD,
                "-c:v", "libx264", "-preset", "fast", "-crf", "23",
                "-c:a", "aac", "-b:a", "192k",
                "-t", String.valueOf(duration),
                "-r", String.valueOf(FPS),
                "-pix_fmt", "yuv420p",
                "-shortest",
                out.getAbsolutePath()
        };
        runFfmpeg(cmd, "image clip: " + image.getName());
        return out;
    }

    /**
     * Converts an existing video file to a portrait MP4 clip, replacing its
     * original audio with the AI narration.
     *
     * <p>The original video audio track is discarded via {@code -map 0:v:0} /
     * {@code -map 1:a:0}.
     *
     * @param video the source video file
     * @param audio the narration MP3
     * @param name  base filename for the output clip (no extension)
     * @return the generated MP4 file
     * @throws Exception if FFmpeg fails
     */
    private File buildVideoClip(File video, File audio, String name)
            throws Exception {

        double dur = getVideoDuration(video);
        File   out = new File(temp.getPath(), name + ".mp4");

        String[] cmd = {
                "ffmpeg", "-y",
                "-i", video.getAbsolutePath(),
                "-i", audio.getAbsolutePath(),
                "-vf", SCALE_PAD,
                "-map", "0:v:0",
                "-map", "1:a:0",
                "-c:v", "libx264", "-preset", "fast", "-crf", "23",
                "-c:a", "aac", "-b:a", "192k",
                "-t", String.valueOf(dur),
                "-r", String.valueOf(FPS),
                "-pix_fmt", "yuv420p",
                "-shortest",
                out.getAbsolutePath()
        };
        runFfmpeg(cmd, "video clip: " + video.getName());
        return out;
    }

    /**
     * Concatenates all clip files into the final output MP4 using the
     * FFmpeg concat demuxer. Applies a final loudness normalization pass.
     *
     * @param clips      ordered list of MP4 clips
     * @param outputFile the destination file
     * @throws Exception if writing the concat list or FFmpeg fails
     */
    private void concatenate(List<File> clips, File outputFile) throws Exception {
        // Write concat list
        File listFile = new File(temp.getPath(), "concat_list.txt");
        try (PrintWriter pw = new PrintWriter(listFile)) {
            for (File clip : clips) {
                // Paths with spaces must be single-quoted in concat format
                pw.println("file '" + clip.getAbsolutePath().replace("'", "'\\''") + "'");
            }
        } catch (FileNotFoundException e) {
            throw new Exception("Could not write concat list: " + e.getMessage(), e);
        }

        String[] cmd = {
                "ffmpeg", "-y",
                "-f", "concat",
                "-safe", "0",
                "-i", listFile.getAbsolutePath(),
                "-c:v", "libx264", "-preset", "fast", "-crf", "22",
                "-c:a", "aac", "-b:a", "192k",
                "-af", LOUDNORM,
                "-pix_fmt", "yuv420p",
                outputFile.getAbsolutePath()
        };
        runFfmpeg(cmd, "concatenation");
        listFile.delete();
    }

    // ─────────────────── UTILITIES ───────────────────

    /**
     * Gets the duration of a video file in seconds using {@code ffprobe}.
     *
     * @param file the video file
     * @return duration in seconds, or 5.0 if detection fails
     */
    private double getVideoDuration(File file) {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "ffprobe", "-v", "quiet",
                    "-show_entries", "format=duration",
                    "-of", "csv=p=0",
                    file.getAbsolutePath());
            pb.redirectErrorStream(true);
            Process p = pb.start();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(p.getInputStream()))) {
                String line = br.readLine();
                if (line != null && !line.isBlank()) {
                    return Double.parseDouble(line.trim());
                }
            }
            p.waitFor();
        } catch (Exception e) {
            System.out.println("  Could not detect video duration, using 5s default.");
        }
        return 5.0;
    }

    /**
     * Runs an FFmpeg command and waits for it to complete.
     *
     * @param cmd      the full command as a String array
     * @param taskName human-readable description for error messages
     * @throws Exception if FFmpeg exits non-zero or cannot start
     */
    private void runFfmpeg(String[] cmd, String taskName) throws Exception {
        try {
            ProcessRunner.run(cmd, taskName);
        } catch (Exception e) {
            throw new Exception("FFmpeg failed for '" + taskName + "': " + e.getMessage(), e);
        }
    }
}

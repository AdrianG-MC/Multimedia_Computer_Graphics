package edu.up.cg.tools;


import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * MetadataExtractor runs ExifTool as a subprocess to read GPS coordinates
 * and capture date from each media file.
 *
 * <p>ExifTool must be installed and in the system PATH.
 * Install: {@code brew install exiftool} (macOS) or
 *          {@code apt install libimage-exiftool-perl} (Linux/WSL).
 */
public class MetadataExtractor {

    /** Date formats that ExifTool may return. */
    private static final DateTimeFormatter[] DATE_FORMATS = {
            DateTimeFormatter.ofPattern("yyyy:MM:dd HH:mm:ss"),
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),
    };

    /**
     * Extracts metadata from all files and wraps them in {@link MediaItem} objects.
     * Files that fail are logged and skipped.
     *
     * @param files raw file list from MediaLoader
     * @return list of MediaItems with populated metadata (never null)
     * @throws Exception if ExifTool is not found on the system
     */
    public List<MediaItem> extractAll(List<File> files) throws Exception {
        ensureExifToolAvailable();

        List<MediaItem> items = new ArrayList<>();
        for (File file : files) {
            MediaItem item = new MediaItem(file);
            try {
                extractOne(item);
                items.add(item);
                System.out.println("  " + item);
            } catch (Exception e) {
                System.out.println("  WARNING: Skipping " + file.getName() + " — " + e.getMessage());
            }
        }

        if (items.isEmpty()) {
            throw new Exception(
                    "No files could be processed. Ensure your media has EXIF metadata with GPS data.");
        }
        return items;
    }

    /**
     * Runs ExifTool on a single file and populates the MediaItem's fields.
     *
     * @param item the item to populate (must have a valid file reference)
     * @throws Exception if ExifTool fails or the file has no GPS data
     */
    public void extractOne(MediaItem item) throws Exception {
        List<String> lines = runExifTool(item.getFile());

        boolean latSet = false;
        boolean lonSet = false;
        boolean latNeg = false;
        boolean lonNeg = false;

        for (String line : lines) {
            String key   = line.contains(":") ? line.substring(0, line.indexOf(':')).trim() : "";
            String value = line.contains(":") ? line.substring(line.indexOf(':') + 1).trim() : "";

            switch (key) {
                case "GPS Latitude"     -> { item.setLatitude(parseGpsDegrees(value));  latSet = true; }
                case "GPS Longitude"    -> { item.setLongitude(parseGpsDegrees(value)); lonSet = true; }
                case "GPS Latitude Ref" -> latNeg = value.equalsIgnoreCase("South");
                case "GPS Longitude Ref"-> lonNeg = value.equalsIgnoreCase("West");
                default -> {
                    if ((key.equals("Date/Time Original") || key.equals("Create Date")
                            || key.equals("Media Create Date"))
                            && item.getCaptureDate() == null) {
                        LocalDateTime dt = parseDate(value);
                        if (dt != null) item.setCaptureDate(dt);
                    }
                }
            }
        }

        // Apply hemisphere sign
        if (latNeg && latSet) item.setLatitude(-Math.abs(item.getLatitude()));
        if (lonNeg && lonSet) item.setLongitude(-Math.abs(item.getLongitude()));

        if (!item.hasGps()) {
            throw new Exception("No GPS data found.");
        }
    }

    // ─────────────────── PRIVATE HELPERS ───────────────────

    /**
     * Runs {@code exiftool <file>} and returns its output as lines.
     *
     * @param file the file to inspect
     * @return raw ExifTool output lines
     * @throws Exception if the process cannot start
     */
    private List<String> runExifTool(File file) throws Exception {
        List<String> lines = new ArrayList<>();
        try {
            ProcessBuilder pb = new ProcessBuilder("exiftool", file.getAbsolutePath());
            pb.redirectErrorStream(true);
            Process p = pb.start();

            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    lines.add(line);
                }
            }
            p.waitFor();
        } catch (java.io.IOException e) {
            throw new Exception(
                    "ExifTool not found. Install it and add to PATH.\n" + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new Exception("ExifTool was interrupted.", e);
        }
        return lines;
    }

    /**
     * Checks that ExifTool is installed and accessible.
     *
     * @throws Exception if {@code exiftool -ver} fails
     */
    private void ensureExifToolAvailable() throws Exception {
        try {
            Process p = new ProcessBuilder("exiftool", "-ver")
                    .redirectErrorStream(true).start();
            p.waitFor();
            if (p.exitValue() != 0) throw new Exception("Non-zero exit");
        } catch (Exception e) {
            throw new Exception(
                    "ExifTool is not installed or not in PATH.\n"
                            + "Install: https://exiftool.org");
        }
    }

    /**
     * Parses GPS decimal degrees from an ExifTool line value.
     * Handles both "21.1458 deg" and "21 deg 8' 44.88\"" formats.
     *
     * @param value the raw value portion of the ExifTool line
     * @return decimal degrees as a positive double
     */
    private double parseGpsDegrees(String value) {
        try {
            // If value starts with a decimal like "19.4326 deg ..."
            String firstNum = value.split("[^0-9.]")[0];
            return Double.parseDouble(firstNum);
        } catch (Exception e) {
            return 0.0;
        }
    }

    /**
     * Parses a {@link LocalDateTime} from an ExifTool date string.
     * Returns null if the string does not match any known format.
     *
     * @param value the raw date string
     * @return parsed date, or null
     */
    private LocalDateTime parseDate(String value) {
        // Strip timezone suffix if present (e.g., "+05:00")
        String cleaned = value.replaceAll("[+-]\\d{2}:\\d{2}$", "").trim();
        for (DateTimeFormatter fmt : DATE_FORMATS) {
            try {
                return LocalDateTime.parse(cleaned, fmt);
            } catch (DateTimeParseException ignored) {
                // Try next format
            }
        }
        return null;
    }
}

package edu.up.cg.tools;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MediaLoader {

    /** Supported photo extensions (lower-case). */
    private static final String[] PHOTO_EXITS = {"jpg", "jpeg", "png"};

    /** Supported video extensions (lower-case). */
    private static final String[] VIDEO_EXITS = {"mp4", "mov", "avi"};

    private final File inputDir;


    /**
     * Constructs a MediaLoader for the given input directory.
     * Creates the directory if it does not exist.
     *
     * @param inputDir the directory to scan for media files
     */
    public MediaLoader(File inputDir) {
        this.inputDir = inputDir;
        if (!inputDir.exists()) {
            inputDir.mkdirs();
            System.out.println("Created input folder: " + inputDir.getPath());
        }
    }

    /**
     * Scans the input directory and returns all supported media files.
     *
     * @return list of valid media files (never null, may be empty)
     * @throws Exception if the input directory cannot be read or has no valid files
     */
    public List<File> load() throws Exception {
        File[] all = inputDir.listFiles();
        if (all == null) {
            throw new Exception("Cannot read input directory: " + inputDir.getAbsolutePath());
        }

        // Sort by filename for deterministic order before metadata extraction
        Arrays.sort(all);

        List<File> accepted = new ArrayList<>();

        for (File f : all) {
            if (f.isFile() && isSupported(f)) {
                accepted.add(f);
                System.out.println("  Found: " + f.getName());
            } else if (f.isFile()) {
                System.out.println("  Skipped (unsupported): " + f.getName());
            }
        }

        if (accepted.isEmpty()) {
            throw new Exception(
                    "No supported media files found in " + inputDir.getAbsolutePath()
                            + "\nSupported: JPG, PNG, JPEG, MP4, MOV, AVI");
        }
        return accepted;
    }

    /**
     * Moves all loaded files from the input folder to the given destination directory.
     * Called at the end of the pipeline to empty the input folder.
     *
     * @param destination the folder to move files into
     * @throws Exception if any file cannot be moved
     */
    public void moveFilesTo(File destination) throws Exception {
        File[] files = inputDir.listFiles();
        if (files == null) return;

        for (File f : files) {
            if (f.isFile()) {
                File target = new File(destination, f.getName());
                try {
                    Files.move(f.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
                    System.out.println("  Moved: " + f.getName());
                } catch (IOException e) {
                    throw new Exception("Could not move file " + f.getName() + ": " + e.getMessage(), e);
                }
            }
        }
    }

    /**
     * Returns true if the file has a supported photo or video extension.
     *
     * @param file the file to check
     * @return true if supported
     */
    public static boolean isSupported(File file) {
        String ext = getExtension(file.getName());

        for (String p : PHOTO_EXITS) {
            if (ext.equals(p)) return true;
        }

        for (String v : VIDEO_EXITS) {
            if (ext.equals(v)) return true;
        }

        return false;
    }

    /**
     * Extracts the lowercase file extension (without the dot).
     *
     * @param name the filename
     * @return lowercase extension, or empty string if none
     */
    public static String getExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1).toLowerCase() : "";
    }


}

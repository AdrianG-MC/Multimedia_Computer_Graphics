package edu.up.cg.utils;


/**
 * ConsoleLogger provides formatted, colored CLI output for the pipeline.
 *
 * <p>Uses ANSI escape codes for color. Colors are automatically disabled
 * on Windows CMD (which does not support ANSI) unless the environment
 * variable {@code FORCE_COLOR=1} is set.
 *
 * <p>This class is non-instantiable (utility class pattern).
 */
public final class ConsoleLogger {

    // ── ANSI color codes ──
    private static final String RESET   = "\u001B[0m";
    private static final String BOLD    = "\u001B[1m";
    private static final String CYAN    = "\u001B[36m";
    private static final String GREEN   = "\u001B[32m";
    private static final String YELLOW  = "\u001B[33m";
    private static final String RED     = "\u001B[31m";
    private static final String MAGENTA = "\u001B[35m";
    private static final String BLUE    = "\u001B[34m";

    /** True when ANSI escape codes are supported. */
    private static final boolean COLOR_ENABLED = isColorSupported();

    private ConsoleLogger() {}

    // ─────────────────── PUBLIC METHODS ───────────────────

    /**
     * Prints the application banner on startup.
     */
    public static void banner() {
        String line = "═".repeat(54);
        System.out.println(color(CYAN + BOLD, line));
        System.out.println(color(CYAN + BOLD, "  ✈  VIDEO CREATOR — AI-Powered Travel Videos"));
        System.out.println(color(CYAN + BOLD, line));
        System.out.println();
    }

    /**
     * Prints a numbered pipeline step header.
     *
     * @param number  step number (e.g. 1, 2, 3…)
     * @param message description of the step
     */
    public static void step(int number, String message) {
        System.out.println();
        System.out.println(color(BLUE + BOLD,
                "── Step " + number + ": " + message + " ──"));
    }

    /**
     * Prints a general informational message (white text).
     *
     * @param message the message to display
     */
    public static void info(String message) {
        System.out.println(color(RESET, "  " + message));
    }

    /**
     * Prints a progress update (yellow, indented with an arrow).
     *
     * @param message the progress message
     */
    public static void progress(String message) {
        System.out.println(color(YELLOW, "  → " + message));
    }

    /**
     * Prints a success message (green with checkmark).
     *
     * @param message the success message
     */
    public static void ok(String message) {
        System.out.println(color(GREEN, "  ✔ " + message));
    }

    /**
     * Prints an error message (red with X mark) to stderr.
     *
     * @param message the error message
     */
    public static void error(String message) {
        System.err.println(color(RED + BOLD, "\n[ERROR] " + message + "\n"));
    }

    /**
     * Prints the final success message with the output file path.
     *
     * @param outputPath absolute path to the generated video
     */
    public static void done(String outputPath) {
        String line = "═".repeat(54);
        System.out.println();
        System.out.println(color(GREEN + BOLD, line));
        System.out.println(color(GREEN + BOLD, "  ✔  VIDEO CREATED SUCCESSFULLY!"));
        System.out.println(color(GREEN,        "  📁 " + outputPath));
        System.out.println(color(GREEN + BOLD, line));
        System.out.println();
    }

    // ─────────────────── PRIVATE HELPERS ───────────────────

    /**
     * Wraps text in ANSI color codes if color output is enabled.
     *
     * @param ansiCode the ANSI escape sequence(s)
     * @param text     the text to colorize
     * @return colorized string, or plain text if color is disabled
     */
    private static String color(String ansiCode, String text) {
        return COLOR_ENABLED ? ansiCode + text + RESET : text;
    }

    /**
     * Detects whether the current terminal supports ANSI color codes.
     * Returns true on macOS/Linux, or when FORCE_COLOR=1 is set.
     */
    private static boolean isColorSupported() {
        String forceColor = System.getenv("FORCE_COLOR");
        if ("1".equals(forceColor)) return true;
        String os = System.getProperty("os.name", "").toLowerCase();
        // Windows CMD does not support ANSI unless using Windows Terminal
        if (os.contains("win")) {
            String term = System.getenv("WT_SESSION"); // Windows Terminal sets this
            return term != null;
        }
        return true; // macOS and Linux
    }
}

package edu.up.cg.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.logging.Logger;

/**
 * ProcessRunner is a reusable utility for running external command-line tools
 * (FFmpeg, ExifTool, etc.) as subprocesses.
 *
 * <p>It:
 * <ul>
 *   <li>Merges stdout and stderr to avoid blocking on unread streams.</li>
 *   <li>Waits for the process to complete.</li>
 *   <li>Throws a descriptive exception if the exit code is non-zero.</li>
 * </ul>
 *
 * <p>This class is non-instantiable (utility class pattern).
 */
public final class ProcessRunner {

    private static final Logger LOG = Logger.getLogger(ProcessRunner.class.getName());

    private ProcessRunner() {}

    /**
     * Runs a command as a subprocess and waits for it to finish.
     *
     * @param cmd      the command and its arguments as a String array
     * @param taskName a human-readable name used in error messages (e.g. "image clip")
     * @throws ProcessException if the process exits with a non-zero code or cannot start
     */
    public static void run(String[] cmd, String taskName) throws ProcessException {
        LOG.fine("Running: " + Arrays.toString(cmd));

        try {
            ProcessBuilder pb = new ProcessBuilder(cmd);
            pb.redirectErrorStream(true); // merge stderr into stdout

            Process process = pb.start();

            // Consume output on the current thread to prevent the pipe buffer from filling
            StringBuilder output = new StringBuilder();
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    output.append(line).append('\n');
                }
            }

            int exitCode = process.waitFor();
            if (exitCode != 0) {
                LOG.warning("Process failed [" + taskName + "]:\n" + output);
                throw new ProcessException(
                        "Command failed for '" + taskName + "' (exit code " + exitCode + ").\n"
                                + "Command: " + Arrays.toString(cmd));
            }

        } catch (IOException e) {
            throw new ProcessException(
                    "Could not start '" + cmd[0] + "'. Is it installed and in PATH?\n"
                            + e.getMessage(), e);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new ProcessException("Process interrupted: " + taskName, e);
        }
    }

    // ── Inner exception class ──

    /**
     * Thrown when a subprocess exits with a non-zero code or cannot be started.
     */
    public static class ProcessException extends Exception {

        public ProcessException(String message) {
            super(message);
        }

        public ProcessException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
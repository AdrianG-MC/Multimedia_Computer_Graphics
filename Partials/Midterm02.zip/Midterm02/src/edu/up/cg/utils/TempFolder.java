package edu.up.cg.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

/**
 * TempFolder creates and manages a single temporary directory used during
 * video processing. It holds intermediate files (clips, audio, images) that
 * are not needed after the final video is rendered.
 *
 * <p>Always call {@link #delete()} in a {@code finally} block to clean up.
 *
 * <pre>{@code
 * TempFolder temp = new TempFolder("vc_work_");
 * try {
 *     File f = new File(temp.getPath(), "clip_01.mp4");
 *     // ... use f ...
 * } finally {
 *     temp.delete();
 * }
 * }</pre>
 */
public class TempFolder {

    private final File directory;

    /**
     * Creates a new temporary directory with the given prefix in the system temp dir.
     *
     * @param prefix prefix for the directory name (e.g. {@code "vc_work_"})
     * @throws RuntimeException if the directory cannot be created
     */
    public TempFolder(String prefix) {
        try {
            directory = Files.createTempDirectory(prefix).toFile();
        } catch (IOException e) {
            throw new RuntimeException("Could not create temp directory: " + e.getMessage(), e);
        }
    }

    /**
     * Returns the underlying {@link File} representing the temp directory.
     *
     * @return the temp directory
     */
    public File getPath() {
        return directory;
    }

    /**
     * Recursively deletes the temp directory and all its contents.
     * Silently ignores errors (best-effort cleanup).
     */
    public void delete() {
        deleteRecursive(directory);
    }

    /**
     * Recursively deletes a directory and all files inside it.
     *
     * @param dir the directory to delete
     */
    private void deleteRecursive(File dir) {
        File[] children = dir.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory()) {
                    deleteRecursive(child);
                } else {
                    child.delete();
                }
            }
        }
        dir.delete();
    }
}
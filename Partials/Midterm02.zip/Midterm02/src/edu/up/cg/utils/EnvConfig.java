package edu.up.cg.utils;

/**
 * Utility for reading required environment variables.
 *
 * <p>All API keys are read from environment variables — never hardcoded.
 * This class is non-instantiable (utility class pattern).
 */
public final class EnvConfig {

    private EnvConfig() {}

    /**
     * Returns the value of a required environment variable.
     *
     * @param name the variable name
     * @return the non-blank value
     * @throws IllegalStateException with a helpful message if the variable is missing or blank
     */
    public static String requireEnv(String name) {
        String value = System.getenv(name);
        if (value == null || value.isBlank()) {
            throw new IllegalStateException(
                    "Required environment variable '" + name + "' is not set.\n"
                            + "Set it before running:\n"
                            + "  export " + name + "=your_key_here   (macOS/Linux)\n"
                            + "  set    " + name + "=your_key_here   (Windows)");
        }
        return value;
    }

    /**
     * Returns the value of an optional environment variable, or a default.
     *
     * @param name         the variable name
     * @param defaultValue returned when the variable is missing or blank
     * @return the variable's value, or {@code defaultValue}
     */
    public static String getEnv(String name, String defaultValue) {
        String value = System.getenv(name);
        return (value != null && !value.isBlank()) ? value : defaultValue;
    }

    /**
     * Returns {@code true} only if all named variables are set and non-blank.
     *
     * @param names variable names to check
     * @return true when all are present
     */
    public static boolean allSet(String... names) {
        for (String name : names) {
            String v = System.getenv(name);
            if (v == null || v.isBlank()) return false;
        }
        return true;
    }
}

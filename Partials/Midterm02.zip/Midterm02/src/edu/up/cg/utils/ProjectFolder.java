package edu.up.cg.utils;

import java.io.File;

/**
 * ProjectFolder determines and creates the next available output project directory.
 *
 * <p>Project directories follow the naming convention {@code Project_N} where
 * {@code N} is an integer incremented automatically based on existing folders:
 *
 * <pre>
 * output/
 *   Project_1/   ← first run
 *   Project_2/   ← second run
 *   Project_3/   ← third run  ← created by this class
 * </pre>
 *
 * <p>The output root directory is created if it does not exist.
 */
public class ProjectFolder {

    private static final String PREFIX = "Project_";

    private final File outputRoot;

    /**
     * Constructs a ProjectFolder using the given output root directory.
     *
     * @param outputRoot the root output directory (e.g. {@code new File("output")})
     */
    public ProjectFolder(File outputRoot) {
        this.outputRoot = outputRoot;
    }

    /**
     * Creates and returns the next project directory (e.g. {@code output/Project_3}).
     *
     * <p>Scans existing {@code Project_N} folders to determine the highest N,
     * then creates {@code Project_(N+1)}.
     *
     * @return the newly created project directory
     * @throws RuntimeException if the directory cannot be created
     */
    public File create() {
        outputRoot.mkdirs();
        int next = findNextNumber();
        File projectDir = new File(outputRoot, PREFIX + next);
        if (!projectDir.mkdirs()) {
            throw new RuntimeException("Could not create project folder: "
                    + projectDir.getAbsolutePath());
        }
        return projectDir;
    }

    /**
     * Scans the output root for existing {@code Project_N} folders and returns
     * the next available index (max existing + 1, or 1 if none exist).
     *
     * @return the next available project number
     */
    private int findNextNumber() {
        int max = 0;
        File[] children = outputRoot.listFiles();
        if (children != null) {
            for (File child : children) {
                if (child.isDirectory() && child.getName().startsWith(PREFIX)) {
                    try {
                        int n = Integer.parseInt(child.getName().substring(PREFIX.length()));
                        if (n > max) max = n;
                    } catch (NumberFormatException ignored) {
                        // Not a numbered project folder — skip
                    }
                }
            }
        }
        return max + 1;
    }
}
# Technical Documentation — Video Creator (CLI)

**Version:** 1.0.0  
**Language:** Java 17 (standard library only)  
**Build:** plain `javac` + `jar`

---

## 1. Architecture

The system is split into seven focused components plus a utility layer. Each component has a single responsibility and communicates only through well-defined method signatures and checked exceptions.

```
┌─────────────────────────────────────────────────────────────┐
│                         Main.java                           │
│                 (Pipeline Orchestrator)                     │
└────────┬────────┬────────┬──────────┬────────┬─────────────┘
         │        │        │          │        │
    ┌────▼──┐ ┌───▼───┐ ┌──▼───┐ ┌───▼──┐ ┌───▼────┐ ┌──────────┐
    │Media  │ │Meta   │ │Media │ │AI    │ │Map     │ │Audio     │
    │Loader │ │data   │ │Sorter│ │Serv. │ │Service │ │Generator │
    │       │ │Extract│ │      │ │      │ │        │ │          │
    └───────┘ └───────┘ └──────┘ └──────┘ └────────┘ └──────────┘
                                                          │
                                                    ┌─────▼──────┐
                                                    │  Video     │
                                                    │  Composer  │
                                                    │ (FFmpeg)   │
                                                    └────────────┘
         All components share:  util/ (ConsoleLogger, EnvConfig,
                                       TempFolder, ProjectFolder,
                                       ProcessRunner)
```

---

## 2. Component Reference

### `Main` — Pipeline Orchestrator

**Package:** `com.videocreator`

Calls each component in order and passes outputs forward. Runs inside a single try-catch-finally block so that the temp folder is always deleted even if the pipeline fails partway through.

**Pipeline order:**
```
MediaLoader.load()
  → MetadataExtractor.extractAll()
    → MediaSorter.sort()
      → AIService.generateOpeningImage()
      → AIService.generateNarrations()
      → AIService.generateInspirationalPhrase()
      → AudioGenerator.synthesize()  (per item + opening + closing)
      → MapService.generateMap()
      → MapService.overlayPhrase()
        → VideoComposer.compose()
          → MediaLoader.moveFilesTo()
```

---

### `MediaLoader` — File Discovery

**Package:** `com.videocreator.loader`

Scans the `input/` directory for files with supported extensions. Uses a `Set<String>` of known photo and video extensions for O(1) lookup.

**Key methods:**
- `load()` → `List<File>` — returns all valid media files; throws `LoaderException` if none found.
- `moveFilesTo(File dest)` — moves every file from `input/` to the project output folder.
- `isPhoto(File)` — static helper used by `VideoComposer` to determine clip-building strategy.

**Supported extensions:**

| Type | Extensions |
|------|-----------|
| Photo | jpg, jpeg, png, heic, tiff, tif, webp |
| Video | mp4, mov, avi, mkv, m4v, wmv |

---

### `MetadataExtractor` — ExifTool Wrapper

**Package:** `com.videocreator.metadata`

Runs `exiftool <file>` as a subprocess via `ProcessBuilder`. Parses stdout line by line looking for GPS and date fields.

**GPS parsing strategy:**
- `GPS Latitude` / `GPS Longitude` — extracts the first decimal number before `deg`.
- `GPS Latitude Ref` = "South" → negates latitude.
- `GPS Longitude Ref` = "West" → negates longitude.
- Result: decimal degrees with correct hemisphere sign.

**Date parsing:**
- Tries `Date/Time Original`, then `Create Date`, then `Media Create Date`.
- Strips timezone offsets before parsing.
- Tries two `DateTimeFormatter` patterns to handle ExifTool's variations.

**Error handling:** files with no GPS are skipped with a warning (non-fatal). If no files pass validation, a `MetadataException` is thrown (fatal).

---

### `MediaSorter` — Chronological Sort

**Package:** `com.videocreator.sorter`

Wraps `Collections.sort()`. Returns a new list — does not mutate the input.

**Sort order:** relies on `MediaItem.compareTo()` which compares `captureDate` fields. Items with no date sort to the end (null-last convention).

---

### `AIService` — Gemini API Client

**Package:** `com.videocreator.ai`

Uses `java.net.http.HttpClient` (built into Java 11+) to call Google Gemini endpoints. All JSON is constructed with `String.format()` and parsed with a hand-written `extractField()` method, avoiding any JSON library dependency.

**Three API calls:**

| Method | Endpoint | Purpose |
|--------|---------|---------|
| `generateOpeningImage()` | `imagen-3.0-generate-001:predict` | 1080×1920 AI image |
| `generateNarrations()` | `gemini-1.5-flash:generateContent` (Vision) | 2-sentence description per item |
| `generateInspirationalPhrase()` | `gemini-3.5-flash:generateContent` | Closing phrase for map |

**Imagen fallback:** if Imagen returns a non-200 response (e.g., free-tier quota exceeded), `createGradientPlaceholder()` produces a navy-to-purple gradient PNG using `java.awt.image.BufferedImage`. The pipeline never fails due to an Imagen quota.

**Vision for photos:** photos are base64-encoded and sent inline using the `inlineData` part format, enabling Gemini to describe the actual image content rather than just its metadata.

---

### `MapService` — Geoapify + Java2D

**Package:** `com.videocreator.map`

**Map generation:**  
Builds a Geoapify Static Maps URL with:
- `style=osm-bright` — clean OpenStreetMap tile style
- Two markers: green `%2300cc55` for Start, red `%23ff3333` for End
- `type=material` markers (Google-style pins)
- Auto-calculated zoom based on coordinate bounding box

**Zoom estimation (`estimateZoom`):**

| Max coordinate delta | Zoom |
|---------------------|------|
| < 0.01° | 15 (neighborhood) |
| < 0.1° | 12 (city) |
| < 0.5° | 10 (metro area) |
| < 2° | 8 (region) |
| < 10° | 6 (country) |
| < 30° | 4 (continent) |
| ≥ 30° | 2 (world) |

**Text overlay (`overlayPhrase`):**  
Uses Java2D (`Graphics2D`) to draw directly onto the downloaded PNG:
1. Semi-transparent black rectangle (alpha=190) over the bottom 360px.
2. White italic font (54pt SansSerif) with `drawWrapped()` for line wrapping.
3. Colored legend: "● Start" (green) and "● End" (red) at the very bottom.

---

### `AudioGenerator` — Google TTS + Loudness Normalization

**Package:** `com.videocreator.audio`

**TTS API:** calls `texttospeech.googleapis.com/v1/text:synthesize` with voice `en-US-Neural2-D` at 0.95x speaking rate. Decodes the base64 `audioContent` field and writes it as MP3.

**Loudness normalization (YouTube standard):**  
After each TTS file is saved, FFmpeg's `loudnorm` filter is applied:

```
ffmpeg -i narration.mp3 -af "loudnorm=I=-14:TP=-1.5:LRA=7" -ar 44100 -ac 2 normalized.mp3
```

| Parameter | Value | YouTube requirement |
|-----------|-------|---------------------|
| Integrated (I) | −14 LUFS | −16 to −14 LUFS |
| True Peak (TP) | −1.5 dBTP | −2 to −1 dBTP |
| LRA | 7 LU | 5 to 10 LU |

**Silence fallback:** if TTS fails, `generateSilence()` creates a silent MP3 of the estimated speaking duration using FFmpeg's `anullsrc` source:

```
ffmpeg -f lavfi -i anullsrc=r=44100:cl=stereo -t <seconds> output.mp3
```

Duration is estimated at ~3 words/second from the narration text length.

---

### `VideoComposer` — FFmpeg Wrapper

**Package:** `com.videocreator.composer`

Builds the final video in three phases:

**Phase 1 — Individual clips:**

*Image clip* (`buildImageClip`):
```bash
ffmpeg -loop 1 -i image.png -i narration.mp3 \
  -vf "scale=1080:1920:force_original_aspect_ratio=decrease,
       pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black" \
  -c:v libx264 -preset fast -crf 23 \
  -c:a aac -b:a 192k -t <dur> -r 30 -pix_fmt yuv420p -shortest \
  clip.mp4
```

*Video clip* (`buildVideoClip`):
- Same scale+pad filter.
- `-map 0:v:0` takes video from original file.
- `-map 1:a:0` replaces audio with AI narration.
- Duration detected via `ffprobe`.

**Portrait scaling filter explained:**
1. `scale=1080:1920:force_original_aspect_ratio=decrease` — shrinks to fit inside 1080×1920 without cropping.
2. `pad=1080:1920:(ow-iw)/2:(oh-ih)/2:black` — centers the result on a black background to fill the full frame.

**Phase 2 — Concat list file:**
```
file '/tmp/vc_work_xxx/clip_00_opening.mp4'
file '/tmp/vc_work_xxx/clip_01_media.mp4'
file '/tmp/vc_work_xxx/clip_02_media.mp4'
file '/tmp/vc_work_xxx/clip_99_map.mp4'
```

**Phase 3 — Concatenation:**
```bash
ffmpeg -f concat -safe 0 -i concat_list.txt \
  -c:v libx264 -preset fast -crf 22 \
  -c:a aac -b:a 192k \
  -af "loudnorm=I=-14:TP=-1.5:LRA=7" \
  -pix_fmt yuv420p \
  output/Project_N/video.mp4
```

The `loudnorm` filter is applied a second time on the final mix to ensure the complete video meets YouTube standards even if clip audio levels vary.

**Clip cleanup:** intermediate clips are deleted in a `finally` block regardless of success or failure.

---

## 3. Utility Classes

| Class | Purpose |
|-------|---------|
| `ConsoleLogger` | Colored, step-numbered CLI output using ANSI codes |
| `EnvConfig` | `requireEnv()` reads API keys from environment; throws with helpful message if missing |
| `TempFolder` | Creates `Files.createTempDirectory()` and deletes it recursively on `delete()` |
| `ProjectFolder` | Scans `output/` for existing `Project_N` folders and creates the next one |
| `ProcessRunner` | Runs any `String[]` command via `ProcessBuilder`, captures stdout+stderr, throws `ProcessException` on non-zero exit |

---

## 4. OOP Principles Applied

| Principle | Implementation |
|-----------|---------------|
| **Single Responsibility** | Each class does exactly one thing (`MediaLoader` only loads, `MediaSorter` only sorts, etc.) |
| **Encapsulation** | All `MediaItem` fields are private; only setters used by the extractor and AI service |
| **Checked exceptions** | Every component declares its own typed exception (`LoaderException`, `AIException`, etc.) forcing callers to handle failures |
| **Composition** | `Main` holds instances of each service; services do not know about each other |
| **Reusability** | `ProcessRunner` is used by both `AudioGenerator` and `VideoComposer`; `EnvConfig` used by all API clients |
| **Comparability** | `MediaItem implements Comparable<MediaItem>` for natural date ordering |
| **Utility class pattern** | `ConsoleLogger`, `EnvConfig`, `ProcessRunner` are non-instantiable (`private` constructor) |

---

## 5. Error Handling Strategy

| Error type | Behavior |
|-----------|---------|
| Missing ExifTool / FFmpeg | `ProcessException` → caught at top level → print error, exit 1 |
| File has no GPS | Skip with warning, continue pipeline |
| Gemini API quota exceeded | Fall back to metadata-based text description |
| Imagen quota exceeded | Fall back to programmatic gradient placeholder image |
| TTS API fails | Fall back to silent audio of estimated duration |
| No valid files in input/ | `LoaderException` → fatal error, exit 1 |
| Missing API key | `IllegalStateException` from `EnvConfig.requireEnv()` → fatal error, exit 1 |

The principle: **AI failures are non-fatal; infrastructure failures (ExifTool, FFmpeg) are fatal.**

---

## 6. Folder Lifecycle

```
Before run:
  input/  ← user places files here
  output/ ← may contain previous Project_N folders

During run:
  /tmp/vc_work_XXXX/   ← temp folder created by TempFolder
    opening_image.png
    map_image.png
    audio_opening.mp3
    audio_01.mp3  ...
    clip_00_opening.mp4  ...

After run:
  input/              ← emptied (files moved)
  output/
    Project_1/
      video.mp4       ← final output
      IMG_001.jpg     ← moved from input/
      VID_002.mp4     ← moved from input/
  /tmp/vc_work_XXXX/  ← deleted by finally block
```

---

## 7. Build Process

```
javac -d out/ --release 17 @sources.txt   ← compile all .java files
jar cfm video-creator.jar manifest.txt -C out/ .  ← package
java -jar video-creator.jar               ← run
```

No Maven. No Gradle. No third-party libraries. Everything uses the Java 17 standard library:
- `java.net.http` — HTTP/1.1 client for all API calls
- `javax.imageio` — PNG read/write for map and placeholder images
- `java.awt` — Java2D for text overlay and gradient generation
- `java.nio.file` — file copy/move operations
- `java.time` — `LocalDateTime` for date parsing and comparison